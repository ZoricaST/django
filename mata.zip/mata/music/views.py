from django.shortcuts import render
from django.http import HttpResponse
def index(request):
	return HttpResponse("<h1>Ovo je nasa strana o muzici</h1><p>ovde ce biti navedeni albumi sa muzikom</p>")