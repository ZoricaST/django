from django.shortcuts import render, get_object_or_404
from .models import Album

def index(request):
	all_albums = Album.objects.all()
	context = {'all_albums': all_albums,
	}
	return render(request,'music/index.html',{'all_albums': all_albums} )
	
def detail(request,album_id):
	album = get_object_or_404(Album, pk=album_id)
	return render(request,'music/detail.html',{'album': album})
	
def favorit(request,album_id):
	album = get_object_or_404(Album, pk=album_id)
	try:
		selected_song = album.song_set.get(pk=request.POST['song'])
	except(KeyError, Song.DoesNotExist):
		return render(request,'music/detail.html',{
		'album': album,
		'error_message':"Niste odabrali odgovarajucu pesmu"
		} )
	else:
		selected_song.is_favorit="True"
		selected_song.save()
		return render(request,'music/detail.html',{'album': album})